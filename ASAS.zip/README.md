# Project Title: All Smart All Star

## Description
All Smart All Star is a revolutionary educational platform that combines entertainment and learning through a unique reality show format. This project aims to enhance educational engagement across Africa by providing innovative learning experiences.

## Project Structure
The project is organized into several directories and files, each serving a specific purpose:

- **css/**: Contains stylesheets for the application.
  - `styles.css`: Styles for the donation page and other components.

- **images/**: Stores image assets used in the application.
  - `logo.png`: The logo image displayed in the header or footer.

- **js/**: Contains JavaScript files for client-side functionality.
  - `scripts.js`: JavaScript code for form validation and interactive elements.

- **src/**: The source directory containing the core application logic.
  - **config/**: Configuration files for the application.
    - `config.php`: Database connection details and API keys for payment gateways.
  - **controllers/**: Contains controller classes that handle application logic.
    - `PaymentController.php`: Handles payment processing logic, including donation validation and interaction with payment gateways.
  - **models/**: Contains data models representing application entities.
    - `Payment.php`: Represents payment data structure with properties for amount, currency, and payment status.
  - **views/**: Contains view files for rendering HTML.
    - `donate.php`: HTML form for the donation page.
    - `confirmation.php`: Displays a confirmation message after a successful donation.

- **vendor/**: Contains third-party libraries managed by Composer.
  - `autoload.php`: Autoloading classes from the vendor directory.

- **.env**: Environment variables for sensitive information like API keys and database credentials.

- **composer.json**: Composer configuration file listing project dependencies.

- **index.php**: Entry point of the application, setting up routing and including necessary files.

## Setup Instructions
1. **Clone the Repository**
   ```
   git clone <repository-url>
   cd all-smart-all-star
   ```

2. **Install Dependencies**
   Ensure you have Composer installed, then run:
   ```
   composer install
   ```

3. **Configure Environment Variables**
   Create a `.env` file in the root directory and add your configuration settings, such as database credentials and API keys.

4. **Run the Application**
   You can run the application using a local server. If you have PHP installed, you can use:
   ```
   php -S localhost:8000
   ```
   Access the application at `http://localhost:8000`.

## Usage
- Navigate to the donation page to make a contribution.
- After submitting a donation, you will be redirected to a confirmation page displaying your donation details.

## Security Considerations
- Ensure that your server uses HTTPS to protect sensitive data.
- Validate and sanitize all user inputs to prevent security vulnerabilities.
- Use prepared statements for database interactions to avoid SQL injection.

## Contribution
Contributions are welcome! Please submit a pull request or open an issue for any suggestions or improvements.

## License
This project is licensed under the MIT License. See the LICENSE file for details.